from django.shortcuts import render, redirect
from django import forms
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.db import connection
from django.contrib import messages
import sys
import base64
from datetime import datetime
from datetime import date
from django.http import HttpResponse
from django.template.loader import get_template
import smtplib

def userlogin(request):
    return render(request, 'web_app/userlogin.html')

def homeuser(request):
    return render(request, 'web_app/homeuser.html') 

def register(request):
    return render(request,'web_app/register.html')       

def userloginfill(request):
    if request.method=='GET':
        email = request.GET["useremail"]
        passw = request.GET["password"]
        cursor = connection.cursor()
        cursor.execute("""SELECT * FROM users WHERE email=%s AND password=%s AND role='patient'""",(email,passw))       
        row = cursor.fetchall()
        users=[]
        data={
            'users':None
        }
        a = cursor.rowcount
        if a!=0:
           return render(request,'web_app/homeuser.html')
        else:
             messages.success(request,'enter correct credentials!!')
             return render(request, 'web_app/register.html')

def userregister(request):
    if request.method=='GET':
        username = request.GET["username"]
        usernumb = request.GET["mobilenum"]
        add = request.GET["address"]
        email = request.GET["useremail"]
        passw = request.GET["password"]
        cursor = connection.cursor()
        try:    
                cursor.execute("""SELECT * FROM users WHERE email=%s AND role='patient'""",[email])   
                row = cursor.fetchall()
                users=[]
                data={
                'users':None
                }
                a = cursor.rowcount
                if a!=0:    
                  return render(request,'web_app/userlogin.html')
                else:
                 cursor.execute("""select max(userid) from users""")  
                 uid=cursor.fetchone()
                 cursor.execute("""INSERT INTO users VALUES (%s,%s,%s,%s,%s,%s,%s)""",(uid[0]+1,username,usernumb,add,'patient',passw,email))      
                 return render(request, 'web_app/userlogin.html')
        finally:
            cursor.close()